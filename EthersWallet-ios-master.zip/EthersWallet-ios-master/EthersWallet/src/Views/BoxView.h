//
//  BoxView.h
//  EthersWallet
//
//  Created by Richard Moore on 2017-09-01.
//  Copyright © 2017 ethers.io. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BoxView : UIView

@property (nonatomic, strong) NSArray *points;

@end
