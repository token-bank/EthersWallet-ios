//
//  main.m
//  EthersWallet
//
//  Created by Richard Moore on 2017-02-01.
//  Copyright © 2017 ethers.io. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
